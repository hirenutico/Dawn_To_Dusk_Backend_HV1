const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const schema = new Schema({
    username: { type: String,  required: true },
    email: { type: String, unique: true, required: true },
    mobile: { type: Number, unique: true, required: true },
    countryCode: { type: String, required: true },
    otp_token:{type:Number},
    verify_otp:{type:Boolean,default:false}
});

schema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('tbl_users', schema);