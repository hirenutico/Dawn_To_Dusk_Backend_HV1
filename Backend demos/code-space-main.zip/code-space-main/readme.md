Coding space
