# Podziękowania:

* Kamil Kucharski https://github.com/maringan for transferring "smsapi" name ownership on http://npmjs.org
