# SMSAPI JavaScript Client

## 1.0.0 - 2015-07-21
* initial commit
