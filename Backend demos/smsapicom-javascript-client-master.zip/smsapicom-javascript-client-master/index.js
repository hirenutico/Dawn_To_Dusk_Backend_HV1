var SMSAPI = require('./lib/smsapi.js');

module.exports = SMSAPI;
